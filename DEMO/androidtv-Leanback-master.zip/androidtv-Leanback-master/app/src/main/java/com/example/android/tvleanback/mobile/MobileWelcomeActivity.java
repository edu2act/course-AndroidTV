package com.example.android.tvleanback.mobile;

import android.app.Activity;
import android.os.Bundle;

import com.example.android.tvleanback.R;

public class MobileWelcomeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mobile_welcome);
    }
}
